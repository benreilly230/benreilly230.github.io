﻿namespace MIS3033_LC_1108_BenReilly.Models
{
    public class Message
    {
        public string status { get; set; } = "success";
        public string message { get; set; } = "";

    }
}
